<?php get_header(); ?>

		<?php // include(TEMPLATEPATH . '/includes/featured.php'); ?>

		<div id="centercol">
		
	

			<?php
				
				include('layouts/blog.php');
				
			?>
			
		</div><!--/centercol-->

<?php get_sidebar(); ?>

<?php get_footer(); ?>