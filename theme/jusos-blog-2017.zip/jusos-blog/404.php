<?php get_header(); ?>

		<div id="centercol" class="page-wrapper">
				
			<article>
				
					<h2>404 | Page Not Found!</h2>
					<div class="archivefeed">Sorry, but the page you were looking for is not here.</div>				
			
			</article><!--/archivebox-->	        					

		</div><!--/col1-->

<?php get_sidebar(); ?>

<?php get_footer(); ?>	
