<?php
/*
Plugin Name: FB Social Plugin Widgets
Plugin URI: http://www.p3000.net
Description: Fügt die drei Facebook Social Plugins Widgets hinzu: Facebook Empfehlungen, Aktivitäten-Feed, und die Facebook Like Box.
Version: 3000.1
Author: P3000
Author URI: http://www.p3000.net

*/

define( 'CD_FBSP_PATH', plugin_dir_path( __FILE__ ) );
define( 'CD_FBSP_NAMe', plugin_basename( __FILE__ ) );

require( CD_FBSP_PATH . 'includes/class-fb-like.php' );
require( CD_FBSP_PATH . 'includes/class-fb-recommends.php' );
require( CD_FBSP_PATH . 'includes/class-fb-activity.php' );

add_action( 'wp_footer', 'cd_fbsp_print_script' );
/**
 * Prints out the Facebook JavaScript code.
 */
function cd_fbsp_print_script()
{
    ?>
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/de_DE/all.js#xfbml=1";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
    <?php
}

/**
* IE doesn't render facebook XFBML unless it finds a certain attribute on the <head>
* tag. This takes care of that.
*/
add_filter( 'language_attributes', 'cd_fbspw_ie_fix', 99 );
function cd_fbspw_ie_fix( $atts )
{
	// if the string already has what we need, bail
	if( preg_match( '/xmlns:fb="(.*)"/', $atts ) ) return $atts;
	$atts .= ' xmlns:fb="http://ogp.me/ns/fb#"';
	return $atts;
}
