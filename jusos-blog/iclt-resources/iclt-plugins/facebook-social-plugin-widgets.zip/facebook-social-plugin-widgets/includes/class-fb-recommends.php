<?php

if( !class_exists( 'CD_FBSP_Recommends_Widget' ) )
{
	class CD_FBSP_Recommends_Widget extends WP_Widget
	{
		function CD_FBSP_Recommends_Widget()
		{
			$widget_ops = array(
				'classname' 	=> 'cd-fb-recommendation-widget',
				'description' 	=> __( 'Das Facebook Recommendations Plugins zeigt dem Nutzer personalisierte Empfehlungen zur Webseite. Das Plugin nutzt zur Datenerfassung alle Interaktionen mit Facebook welche von der Webseite ausgehen.', 'cd-fbspw' )
			);
			
			$this->WP_Widget( 'CD_FBSP_Recommends_Widget', __( 'Facebook Recommendations', 'cd-fbspw' ), $widget_ops );
		}
		
		function form( $instance )
		{
			$defaults = array(
				'title'			=> 'Top Articles',
				'url' 			=> get_bloginfo('url'),
				'width'			=> 284,
				'show_header' 	=> 'off'
			);
			
			$instance = wp_parse_args( (array) $instance, $defaults );
			extract( $instance );
			
			?>
			<p>
				<label for="cd-fbr-title"><?php _e( 'Title:', 'cd-fbspw' ); ?></label>
				<input id="cd-fbr-title" class="widefat" name="<?php echo $this-> get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>
			<p>
				<label for="cd-fbr-url"><?php _e( 'Website URL:', 'cd-fbspw' ); ?></label>
				<input id="cd-fbr-url" class="widefat" name="<?php echo $this-> get_field_name( 'url' ); ?>" type="text" value="<?php echo esc_attr( $url ); ?>" />
			</p>
			<p>
				<input id="cd-fbr-header" name="<?php echo $this->get_field_name( 'show_header' ); ?>" type="checkbox" <?php checked( $show_header, 'on' ); ?> />
				<label for="cd-fbr-header"><?php _e( 'show the facebook header', 'cd-fbspw' ); ?></label>
			</p>
			<?php	
		}
		
		function update( $new_instance, $old_instance )
		{
			$instance = $old_instance;
			$instance['title'] = isset( $new_instance['title'] ) ? strip_tags( $new_instance['title'] ) : '';
			$instance['url'] = isset( $new_instance['url'] ) ? esc_url( $new_instance['url'], array( 'http', 'https' ) ) : '';
			$instance['width'] = isset( $new_instance['width'] ) ? absint( $new_instance['width'] ) : 300;
			$instance['color_scheme'] = strip_tags( $new_instance['color_scheme'] );
			$instance['show_header'] = isset( $new_instance['show_header'] ) && $new_instance['show_header'] ? 'on' : 'off';
			
			return $instance;
		}
		
		function widget( $args, $instance )
		{
			extract( $args );
			
			// Get our widget variables
			$title = apply_filters( 'widget_title', $instance['title'] );
			$width = ' width="284"';
			$url = empty( $instance['url'] ) ? ' site="http://wordpress.org/"' : ' site="' . $instance['url'] . '"';
			$header = $instance['show_header'] == 'on' ? ' header="true"' : ' header="false"';
			
			// Render the widget
			echo $before_widget;
			if( !empty( $title ) )
			{
				echo $before_title . $title . $after_title;
			}
			echo '<fb:recommendations' . $url . $width . $header . '></fb:recommendations>';
			echo $after_widget;
		}
	} // end class
	
	/**
	* Register the widget here to make sure we get the right class...
	*/
	add_action( 'widgets_init', 'cd_fbsp_recommends_register' );
	function cd_fbsp_recommends_register()
	{		
		register_widget( 'CD_FBSP_Recommends_Widget' );
	}
	
} // end class_exists
