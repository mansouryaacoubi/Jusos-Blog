<?php
/*
Plugin Name: Jusos Flickr
Plugin URI: http://www.jusos.de
Description: A plugin that adds a widget to display a Flickr stream
Version: 3000.0
Author: P3000
Author URI: http://www.p3000.net/
License: GPL2
*/

class wp_jusos_flickr_plugin extends WP_Widget {

	function wp_jusos_flickr_plugin() {
            $widget_ops = array(
				'classname' 	=> 'jusos-flickr-widget',
				'description' 	=> __('Displays a Flickr Stream', 'jss-flckr' ),
			);
			
			$this->WP_Widget( 'wp_jusos_flickr_plugin', __('Jusos Flickr', 'jss-flckr' ), $widget_ops );
        }

	function form($instance) {

        // Check values
        if( $instance) {
             $title = esc_attr($instance['title']);
             $flickr_id = esc_attr($instance['flickr_id']);
             $flickr_count = esc_attr($instance['flickr_count']);
        } else {
             $title = '';
             $flickr_id = '';
             $flickr_count = 9;
        }
        ?>
        <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Widget Title', 'wp_widget_plugin'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
        </p>
        <p>
        <label for="<?php echo $this->get_field_id('flickr_id'); ?>"><?php _e('Flickr ID', 'wp_widget_plugin'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('flickr_id'); ?>" name="<?php echo $this->get_field_name('flickr_id'); ?>" type="text" value="<?php echo $flickr_id; ?>" />
        </p>
        <p>
        <label for="<?php echo $this->get_field_id('flickr_count'); ?>"><?php _e('Number of Photos', 'wp_widget_plugin'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('flickr_count'); ?>" name="<?php echo $this->get_field_name('flickr_count'); ?>" type="text" value="<?php echo $flickr_count; ?>" />
        </p>
        <?php
        }

	function update($new_instance, $old_instance) {
             $instance = $old_instance;
             $instance['title'] = strip_tags($new_instance['title']);
             $instance['flickr_id'] = strip_tags($new_instance['flickr_id']);
             $instance['flickr_count'] = strip_tags($new_instance['flickr_count']);
             return $instance;
        }

	function widget($args, $instance) {
            extract( $args );
            
            $title = apply_filters('widget_title', $instance['title']);
            $flickr_count = $instance['flickr_count'];
            $flickr_id = $instance['flickr_id'];
           
            echo $before_widget;
            // Display the widget
            echo '<div class="widget-text wp_widget_plugin_box jusos-flickr-box">';

            // Check if title is set
            if ( $title ) {
               echo $before_title . $title . $after_title;
            }
            
            // Output box
            if ($flickr_id) { ?>
    
            <div class="box2" style="margin-bottom:15px;">
                <div class="top"></div>
                <div class="spacer flickr">

                    <h5>Neueste <span style="color:#0063DC">Flick</span><span style="color:#FF0084">r</span> Fotos</h5>
                    <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=<?php echo $flickr_count; ?>&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user=<?php echo $flickr_id; ?>"></script>		

                        </div><!--/spacer -->
                <div class="fix"></div>        
                <div class="bot"></div>
            </div>

            <!--/box2 -->

            <?php }
            
            
            
            echo '</div>';
            echo $after_widget;
        }
}

// register widget
add_action('widgets_init', create_function('', 'return register_widget("wp_jusos_flickr_plugin");'));

?>