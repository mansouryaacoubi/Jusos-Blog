<?php
/*
Plugin Name: @jusos Tweets
Plugin URI: http://www.jusos.de
Description: A plugin that adds a widget to show the jusos twitter timeline
Version: 3000.0
Author: P3000
Author URI: http://www.p3000.net/
License: GPL2
*/

class wp_jusos_tweets_plugin extends WP_Widget {

	function wp_jusos_tweets_plugin() {
            $widget_ops = array(
				'classname' 	=> 'jusos-tweet-widget',
				'description' 	=> __('Displays @jusos Twitter Timeline', 'jss-twttr' ),
			);
			
			$this->WP_Widget( 'wp_jusos_tweets_plugin', __('@jusos Tweets', 'jss-twttr' ), $widget_ops );
        }

	function form($instance) {

        // Check values
        if( $instance) {
             $title = esc_attr($instance['title']);
        } else {
             $title = '';
        }
        ?>
        <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Widget Title', 'wp_widget_plugin'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
        </p>
        <?php
        }

	function update($new_instance, $old_instance) {
             $instance = $old_instance;
             $instance['title'] = strip_tags($new_instance['title']);
             return $instance;
        }

	function widget($args, $instance) {
            extract( $args );
            
            $title = apply_filters('widget_title', $instance['title']);
            echo $before_widget;
            // Display the widget
            echo '<div class="widget-text wp_widget_plugin_box jusos-tweets-box">';

            // Check if title is set
            if ( $title ) {
               echo $before_title . $title . $after_title;
            }

            // Output box
            echo '<a class="twitter-timeline" href="https://twitter.com/jusos" data-widget-id="339716012272406528">Tweets von @jusos</a>';
            echo '<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?"http":"https";if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>';
            
            echo '</div>';
            echo $after_widget;
        }
}

// register widget
add_action('widgets_init', create_function('', 'return register_widget("wp_jusos_tweets_plugin");'));

?>