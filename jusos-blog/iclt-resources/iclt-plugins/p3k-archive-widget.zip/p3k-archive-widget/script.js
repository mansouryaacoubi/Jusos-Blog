jQuery(document).ready(function() {
    
    jQuery('li.p3k-archive-year a.yearmore').click(function() {
            jQuery('a.yearmore').removeClass('active');
            jQuery('a.yearmore').parent().children('ul').hide('fast');
            jQuery(this).addClass('active');
            jQuery(this).parent().children('ul').show('fast');
       
    });
        
    jQuery('li.p3k-archive-year:first-child ul').css("display", "block");
    jQuery('li.p3k-archive-year:first-child a.yearmore').addClass('active');
                
});